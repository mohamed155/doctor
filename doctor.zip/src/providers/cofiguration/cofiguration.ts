import { Injectable } from '@angular/core';

@Injectable()
export class ConfigurationProvider {
  public url = 'http://mashfac.com/';
}
